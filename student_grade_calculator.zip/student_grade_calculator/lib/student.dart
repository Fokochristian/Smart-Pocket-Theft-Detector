class Student {
  String name;
  List<double> scores;

  Student({required this.name, required this.scores});

  double calculateAverage() {
    if (scores.isEmpty) return 0.0;
    return scores.reduce((a, b) => a + b) / scores.length;
  }

  String calculateGrade() {
    double avg = calculateAverage();

    if (avg >= 90) return "A";
    if (avg >= 80) return "B";
    if (avg >= 70) return "C";
    if (avg >= 60) return "D";
    return "F";
  }

  String getRemark() {
    switch (calculateGrade()) {
      case "A":
        return "Excellent";
      case "B":
        return "Very Good";
      case "C":
        return "Good";
      case "D":
        return "Pass";
      default:
        return "Fail";
    }
  }
}
