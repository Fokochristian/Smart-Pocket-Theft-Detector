import 'dart:io';
import 'student.dart';

class GradeCalculator {
  void start() {
    print("=================================");
    print("     STUDENT GRADE CALCULATOR");
    print("=================================");

    stdout.write("Enter student name: ");
    String? name = stdin.readLineSync();

    if (name == null || name.trim().isEmpty) {
      print("Invalid name. Program terminated.");
      return;
    }

    List<double> scores = [];

    while (true) {
      stdout.write("Enter score (0-100) or type 'done': ");
      String? input = stdin.readLineSync();

      if (input == null) continue;

      if (input.toLowerCase() == "done") break;

      double? score = double.tryParse(input);

      if (score == null) {
        print("Invalid input. Please enter a number.");
        continue;
      }

      if (score < 0 || score > 100) {
        print("Score must be between 0 and 100.");
        continue;
      }

      scores.add(score);
    }

    if (scores.isEmpty) {
      print("No scores entered.");
      return;
    }

    Student student = Student(name: name, scores: scores);

    print("\n========== RESULT ==========");
    print("Student Name : ${student.name}");
    print("Scores       : ${student.scores}");
    print("Average      : ${student.calculateAverage().toStringAsFixed(2)}");
    print("Grade        : ${student.calculateGrade()}");
    print("Remark       : ${student.getRemark()}");
    print("============================");
  }
}
